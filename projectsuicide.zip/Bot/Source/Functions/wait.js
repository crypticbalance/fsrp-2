export function wait(ms) {
    return new Promise(resolve => setTimeout(resolve, ms * 1000));
}